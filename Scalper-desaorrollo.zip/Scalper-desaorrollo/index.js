require('dotenv').config();
const WebSocket = require("ws");
const ws = new WebSocket(`${process.env.STREAM_URL}btcusdt@markPrice@1s`) //par que queiro monitorear, que quiero(market price), lapso
const wsCandles = new WebSocket(`${process.env.STREAM_URL}btcusdt@kline_1m`) //stream candles

const api = require("./api");
const instrumentos= require("./instrumentos")
const funciones = require("./funciones")

let datosDePosicion;


/* api.consultarPosicion("btcusdt")
.then(data => {
    datosDePosicion=data;
    console.log(data[0].entryPrice)
    
})
.catch(err => {
    console.log(err)
    posicionAbierta=false;
    datosDePosicion=undefined;
})

 */





